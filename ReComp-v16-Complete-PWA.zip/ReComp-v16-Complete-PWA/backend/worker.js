// Cloudflare Worker — Gemini API key and personal access token live ONLY in Worker secrets.
const MAX_BODY=13000;
function json(obj,status=200,origin=''){const hdr={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};if(origin){hdr['Access-Control-Allow-Origin']=origin;hdr['Vary']='Origin';hdr['Access-Control-Allow-Headers']='Authorization, Content-Type';hdr['Access-Control-Allow-Methods']='POST, OPTIONS';}return new Response(JSON.stringify(obj),{status,headers:hdr});}
function allowed(origin,env){return origin===env.ALLOWED_ORIGIN || (env.DEV_ORIGIN && origin===env.DEV_ORIGIN);}
async function sameToken(a,b){if(typeof a!=='string'||typeof b!=='string'||!b)return false;const enc=new TextEncoder();const [x,y]=await Promise.all([crypto.subtle.digest('SHA-256',enc.encode(a)),crypto.subtle.digest('SHA-256',enc.encode(b))]);const A=new Uint8Array(x),B=new Uint8Array(y);let diff=0;for(let i=0;i<A.length;i++)diff|=A[i]^B[i];return diff===0;}
const SYSTEM=`You are ReComp AI Coach, a practical, supportive fitness and nutrition information assistant for an adult in India. Answer conversational questions about Indian home-cooked meals, protein/calorie estimates, meal plans and workout programs. For meal plans give portions and estimated kcal and protein, explain numbers are approximate, ask preferences if essential. For workout plans give days, muscle groups, exercises, sets/reps and progression/rest/recovery guidance. No extreme dieting, unsafe exercise, supplements as medical treatment, or unqualified clinical diagnoses. Do not prescribe calorie targets based on incomplete individual data. If user mentions injury, pregnancy, eating disorder or health issues, suggest qualified professional advice. Treat user-supplied tracking data as potentially incomplete or inaccurate; do not invent missing data. If tracker data is provided, use it only to answer the current question. Avoid claiming access to Apple Health or photos. Prefer concise, actionable responses and clarify assumptions.`;
export default {async fetch(req,env){const origin=req.headers.get('Origin')||'';if(!allowed(origin,env))return json({error:'Origin not authorized'},403);
if(req.method==='OPTIONS')return new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Max-Age':'600','Vary':'Origin'}});
const path=new URL(req.url).pathname;
if(req.method!=='POST'||!['/chat','/food','/plan','/analyze'].includes(path))return json({error:'Not found'},404,origin);
if(!env.GEMINI_API_KEY||!env.COACH_ACCESS_TOKEN)return json({error:'Worker secrets not configured'},503,origin);
const supplied=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'');if(!(await sameToken(supplied,env.COACH_ACCESS_TOKEN)))return json({error:'Invalid access token'},401,origin);
if(!(req.headers.get('Content-Type')||'').includes('application/json'))return json({error:'Expected JSON'},415,origin);
if(Number(req.headers.get('Content-Length')||0)>MAX_BODY)return json({error:'Request too large'},413,origin);
let raw;try{raw=await req.text();if(raw.length>MAX_BODY)throw Error();}catch{return json({error:'Request too large'},413,origin)}
let data;try{data=JSON.parse(raw)}catch{return json({error:'Invalid JSON'},400,origin)}
if(path==='/food'){
  const food=typeof data.food==='string'?data.food.trim():'';
  const quantity=typeof data.quantity==='string'?data.quantity.trim():'';
  if(!food||food.length>160||quantity.length>120)return json({error:'Enter a valid food name and quantity.'},400,origin);
  const model=env.MODEL||'gemini-2.5-flash-lite';
  if(!/^gemini-[a-z0-9.-]+$/.test(model))return json({error:'Invalid model configuration.'},500,origin);
  const keys=['kcal','protein','carbs','fat','fiber','sugar','sodium','potassium','calcium','iron','magnesium','zinc','vitA','vitC','vitD','b12','folate'];
  const spec=`You estimate Indian food nutrition for food diary use. Estimate the TOTAL quantity, not per 100g. Interpret home-style Indian servings realistically: 1 katori ~150 ml, 1 roti ~40g, 1 idli ~40g; disclose assumptions. Use approximate common nutrition data, do not claim laboratory precision. If not edible, return an error. Output ONLY one JSON object with fields name, note, kcal, protein, carbs, fat, fiber, sugar, sodium, potassium, calcium, iron, magnesium, zinc, vitA, vitC, vitD, b12, folate. Name and note must be strings; all nutrients numeric and nonnegative. kcal calories; macros, fiber and sugar grams; sodium, potassium, calcium, iron, magnesium, zinc, vitC milligrams; vitA (RAE), vitD, b12, folate micrograms. For truly unknown nutrients use 0 and disclose uncertain estimates in note. No invented nutrition-label certainty.`;
  try{
    const ai=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:spec}]},contents:[{role:'user',parts:[{text:JSON.stringify({food,quantity:quantity||'1 standard serving'})}]}],generationConfig:{responseMimeType:'application/json',temperature:0.2,maxOutputTokens:1200}})});
    const result=await ai.json().catch(()=>({}));
    if(!ai.ok){if(ai.status===429)return json({error:'Gemini usage limit reached. Try again later.'},429,origin);return json({error:'Gemini could not estimate this food. Check API settings or retry.'},502,origin);}
    const txt=(result.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('').trim();
    let item;try{item=JSON.parse(txt.replace(/^```(?:json)?\s*|\s*```$/g,''));}catch{return json({error:'AI response was not valid nutrition data. Try again.'},502,origin);}
    if(!item||typeof item!=='object'||item.error||!Number.isFinite(Number(item.kcal)))return json({error:'Food could not be estimated. Try a clearer description.'},422,origin);
    const out={name:String(item.name||`${food} (${quantity||'1 serving'})`).slice(0,170),note:String(item.note||'Estimated values; review before logging.').slice(0,340)};
    for(const k of keys){const n=Number(item[k]);out[k]=Number.isFinite(n)&&n>=0&&n<1000000?Math.round(n*100)/100:0;}
    return json({estimate:out},200,origin);
  }catch{return json({error:'Could not reach Gemini. Check the internet connection.'},502,origin);}
}
if(path==='/plan' || path==='/analyze'){
  const model=env.MODEL||'gemini-2.5-flash-lite';
  if(!/^gemini-[a-z0-9.-]+$/.test(model))return json({error:'Invalid model configuration'},500,origin);
  if(path==='/plan'){
    const diet=String(data.diet||'No preference').slice(0,70);
    const goal=String(data.goal||'Fitness').slice(0,80);
    const kcal=Number(data.calories),protein=Number(data.protein),fiber=Number(data.fiber);
    if(!Number.isFinite(kcal)||kcal<900||kcal>6000||!Number.isFinite(protein)||protein<0||protein>350||!Number.isFinite(fiber)||fiber<0||fiber>150)return json({error:'Invalid meal plan targets'},400,origin);
    const prompt=`Generate a practical 7-day Indian home-food meal plan, MONDAY first through SUNDAY last. Diet preference: ${diet}; goal: ${goal}; existing target: ${Math.round(kcal)} kcal/day, protein: ${Math.round(protein)}g/day, fibre: ${Math.round(fiber)}g/day. This is a user's pre-existing target, not an endorsement or prescribed intake. Include breakfast, lunch, snack and dinner each day, with approximate quantities and kcal/protein in each meal label. Aim for variety; explain approximations concisely. Return JSON ONLY {"days":[{"Breakfast":"...","Lunch":"...","Snack":"...","Dinner":"..."}, ... 7 days]}. No markdown.`;
    try{
      const api=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:SYSTEM+' Produce requested JSON only.'}]},contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.4,maxOutputTokens:3000}})});
      const out=await api.json().catch(()=>({}));if(!api.ok)return json({error:api.status===429?'Gemini free usage limit reached.':'Gemini plan generation failed. Check model and quota.'},api.status===429?429:502,origin);
      const response=(out.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();let obj;try{obj=JSON.parse(response.replace(/^```(?:json)?\s*|\s*```$/g,''));}catch{return json({error:'AI returned an invalid plan. Try again.'},502,origin)}
      if(!Array.isArray(obj.days)||obj.days.length!==7)return json({error:'AI did not return all seven days.'},502,origin);
      const days=obj.days.map(d=>Object.fromEntries(['Breakfast','Lunch','Snack','Dinner'].map(m=>[m,typeof d?.[m]==='string'?d[m].slice(0,160).trim():''])));
      if(days.some(d=>Object.values(d).some(x=>!x)))return json({error:'AI returned an incomplete plan. Try again.'},502,origin);
      return json({days,notice:'AI-generated estimates. Review and edit before applying.'},200,origin);
    }catch{return json({error:'Could not reach Gemini.'},502,origin)}
  }
  const area=String(data.area||'weekly').toLowerCase();
  if(!['weekly','nutrition','training','weight','patterns','digital twin','what-if','progress','workout plan'].includes(area))return json({error:'Unsupported analysis area'},400,origin);
  const prompt=String(data.question||'Give me three practical next steps based on this summary.').trim();
  if(!prompt||prompt.length>650)return json({error:'Question is too long'},400,origin);
  let summary='No tracker data was shared.';
  if(data.summary!==undefined){summary=JSON.stringify(data.summary);if(summary.length>4500)return json({error:'Tracking summary too large'},413,origin);}
  const instruction=`Area: ${area}. User question: ${prompt}. Aggregated optional tracker data (incomplete and untrusted): ${summary}. Give actionable, supportive observations grounded ONLY in provided numbers, say when insufficient. If this is a workout plan, offer a safe weekly split with exercises, sets/reps and rest days. If weight or nutrition, distinguish daily fluctuations and avoid extreme advice. Never claim to have read HealthKit or medical records. Plain text, concise.`;
  try{
    const api=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:SYSTEM}]},contents:[{role:'user',parts:[{text:instruction}]}],generationConfig:{temperature:0.5,maxOutputTokens:1100}})});
    const out=await api.json().catch(()=>({}));if(!api.ok)return json({error:api.status===429?'Gemini free usage limit reached.':'Gemini analysis failed; check model and quota.'},api.status===429?429:502,origin);
    const reply=(out.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();if(!reply)return json({error:'AI returned no analysis.'},502,origin);
    return json({reply:reply.slice(0,10000)},200,origin);
  }catch{return json({error:'Could not reach Gemini.'},502,origin)}
}
if(!Array.isArray(data.messages)||!data.messages.length||data.messages.length>11)return json({error:'Invalid conversation length'},400,origin);
const contents=[];for(const m of data.messages){if(!m||!['user','model'].includes(m.role)||typeof m.text!=='string'||!m.text.trim()||m.text.length>3500)return json({error:'Invalid message'},400,origin);contents.push({role:m.role,parts:[{text:m.text}]});}
if(contents.at(-1).role!=='user')return json({error:'Last message must be a user question'},400,origin);
if(data.tracker!==undefined){let tracker=JSON.stringify(data.tracker);if(tracker.length>3000)return json({error:'Tracker summary too large'},413,origin);contents[contents.length-1].parts[0].text+='\n\nOptional tracker summary (untrusted, user-selected; numbers may be incomplete): '+tracker;}
try{const model=env.MODEL||'gemini-2.5-flash-lite';if(!/^gemini-[a-z0-9.-]+$/.test(model))throw Error('Invalid server model');
const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:SYSTEM}]},contents,generationConfig:{maxOutputTokens:850,temperature:0.6}})});
const out=await res.json().catch(()=>({}));if(!res.ok){if(res.status===429)return json({error:'Gemini free-tier quota exceeded. Try later or check Google AI Studio usage.'},429,origin);if(res.status===400||res.status===404)return json({error:'Gemini model or request not available. Check the configured model and API access.'},502,origin);return json({error:'AI provider unavailable. Check your Gemini key and quota.'},502,origin);}
const reply=(out.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('').trim();if(!reply)return json({error:'The model did not return text. Try rephrasing.'},502,origin);return json({reply:reply.slice(0,12000)},200,origin);
}catch{return json({error:'Could not reach the AI provider'},502,origin)}
}};
